# Contains the lists for the tic tac toe board
board_1 = [[' ', ' ', ' '], [' ', ' ', ' '], [' ', ' ', ' ']]
board_2 = [[' ', ' ', ' '], [' ', ' ', ' '], [' ', ' ', ' ']]
board_3 = [[' ', ' ', ' '], [' ', ' ', ' '], [' ', ' ', ' ']]
board_4 = [[' ', ' ', ' '], [' ', ' ', ' '], [' ', ' ', ' ']]
board_5 = [[' ', ' ', ' '], [' ', ' ', ' '], [' ', ' ', ' ']]
board_6 = [[' ', ' ', ' '], [' ', ' ', ' '], [' ', ' ', ' ']]
board_7 = [[' ', ' ', ' '], [' ', ' ', ' '], [' ', ' ', ' ']]
board_8 = [[' ', ' ', ' '], [' ', ' ', ' '], [' ', ' ', ' ']]
board_9 = [[' ', ' ', ' '], [' ', ' ', ' '], [' ', ' ', ' ']]

# The box the user chooses to change
box = [[]]


# Makes sure the box number the user enters is valid. The function then coordinates the number with one of the lists and assigns it to box. It also checks and makes sure the board the user wants hasn't already been completed.
def get_valid_box_index(prompt):
    while True:
        index = int(input(prompt))
        if index == 1 or index == 2 or index == 3 or index == 4 or index == 5 or index == 6 or index == 7 or index == 8 or index == 9:
            if index == 1:
                box = board_1
            if index == 2:
                box = board_2
            if index == 3:
                box = board_3
            if index == 4:
                box = board_4
            if index == 5:
                box = board_5
            if index == 6:
                box = board_6
            if index == 7:
                box = board_7
            if index == 8:
                box = board_8
            if index == 9:
                box = board_9
            if x_won(box) or o_won(box) == True:
                print("Enter a board that has not been completed!")
            else:
                return box
        else:
            print("Must be 1-9 inclusive.")

# Makes sure the row and column numbers the user enters are valid.
def get_valid_index(prompt):
    while True:
        try:
            index = int(input(prompt))
            if index >= 0 and index <= 2:
                return index
                #returns an integer
            print("Must be 0 - 2 inclusive!")
        except ValueError:
            print("Must be an integer!")

# Prints the tic tac toe boards.
def print_board():
    for i in range(3):
        print(str(board_1[i]) + "|" + str(board_2[i]) + "|" + str(board_3[i]))
    print("-----------------------------------------------")
    for i in range(3):
        print(str(board_4[i]) + "|" + str(board_5[i]) + "|" + str(board_6[i]))
    print("-----------------------------------------------")
    for i in range(3):
        print(str(board_7[i]) +"|" + str(board_8[i]) + "|" + str(board_9[i]))
# Sets the first turn to x
turn = "x"

# The user enters row and column values. This function makes sure the space they entered isn't taken and sets the space to x or o if it is not.
def play_board(box):
    while True:
        global turn
        row = get_valid_index("Row: ")
        column = get_valid_index("Column: ")
        if box[row][column] != ("x" or "o"):
            if turn == "x":
                box[row][column] = "x"
                break
            elif turn == "o":
                box[row][column] ="o"
                break
        else:
            print("This space is taken!")
# Checks to see if x won the board
def x_won(box):
    if box[0][0] == "x" and box[1][0] == "x" and box[2][0] == "x":
            return True
            #returns a boolean
    if box[1][0] == box[1][1] == box[1][2] == "x":
            return True
    if box[2][0] == box[2][1] == box[2][2] == "x":
            return True
            
    if box[0][0] == box[1][0] == box[2][0]== "x":
            return True
    if box[0][1] == box[1][1] == box[2][1]== "x":
            return True
    if box[0][2] == box[1][2] == box[2][2]== "x":
            return True
        
    if box[0][0] == box[1][1] == box[2][2]== "x":
        return True
    
    if box[2][0] == box[1][1] == box[0][2]== "x":
        return True
    
    return False
# Checks to see if x won the board
def o_won(box):
    for i in range(3):
        if box[i][0] == box[i][1] == box[i][2] == "o":
            return True
        
        if box[0][i] == box[1][i] == box[2][i]== "o":
            return True
        
    if box[0][0] == box[1][1] == box[2][2]== "o":
        return True
    
    if box[2][0] == box[1][1] == box[0][2]== "o":
        return True
    
    return False
#Checks to see if x or o won the game and announces it.
def check_won():
    if (x_won(board_1) or o_won(board_1)) and (x_won(board_2) or o_won(board_2)) and (x_won(board_3) or o_won(board_3)) == True:
        print("Congrats! " + turn + " won!")
        return True
    if (x_won(board_4) or o_won(board_4)) and (x_won(board_5) or o_won(board_5)) and (x_won(board_6) or o_won(board_6)) == True:
        print("Congrats! " + turn + " won!")
        return True
    if (x_won(board_7) or o_won(board_7)) and (x_won(board_8) or o_won(board_8)) and (x_won(board_9) or o_won(board_9)) == True:
        print("Congrats! " + turn + " won!")
        return True
    if (x_won(board_1) or o_won(board_1)) and (x_won(board_4) or o_won(board_4)) and (x_won(board_7) or o_won(board_7)) == True:
        print("Congrats! " + turn + " won!")
        return True
    if (x_won(board_2) or o_won(board_2)) and (x_won(board_5) or o_won(board_5)) and (x_won(board_8) or o_won(board_8)) == True:
        print("Congrats! " + turn + " won!")
        return True
    if (x_won(board_3) or o_won(board_3)) and (x_won(board_6) or o_won(board_6)) and (x_won(board_9) or o_won(board_9)) == True:
        print("Congrats! " + turn + " won!")
        return True
    if (x_won(board_1) or o_won(board_1)) and (x_won(board_5) or o_won(board_5)) and (x_won(board_9) or o_won(board_9)) == True:
        print("Congrats! " + turn + " won!")
        return True
    if (x_won(board_3) or o_won(board_3)) and (x_won(board_5) or o_won(board_5)) and (x_won(board_7) or o_won(board_7)) == True:
        print("Congrats! " + turn + " won!")
        return True
    return False

# The while loop continues the game process until someone has won.
while True:
    print_board()
    box = get_valid_box_index("Box: ")
    play_board(box)
    x_won(box)
    o_won(box)
    winner = check_won()
    if turn == "x":
        turn = "o"
    elif turn == "o":
        turn = "x"
    if winner == True:
         break